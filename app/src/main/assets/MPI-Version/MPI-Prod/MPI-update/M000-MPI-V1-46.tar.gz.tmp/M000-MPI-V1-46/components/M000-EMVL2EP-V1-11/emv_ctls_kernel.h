#ifndef __EMV_CTLS_KERNEL_H__
#define __EMV_CTLS_KERNEL_H__

#include <stdint.h>
#include "emv_kernel.h"

// Maximum Number and Size of Reader Combinations
#define NB_MAX_READER_COMBINATIONS			32
#define SIZE_READER_COMBINATION				47

// Maximum Number of Applications
#define NB_MAX_APP							16

// Maximum Number of Dynamic Limits Sets
#define NB_MAX_DRL							4

// Maximum Number of Kernels
#define NB_KERNELS							255

// Errors
#define EMV_NO_CARD_TIMEDOUT				8
#define EMV_TRANSACTION_CANCELED			9

// Entry Point Kernels Identifiers
#define KERNEL_1							0x01	// Old Visa Wave 1
#define KERNEL_2							0x02	// Mastercard PayPass 3.0
#define KERNEL_3							0x03	// Visa payWave 2.1
#define KERNEL_4							0x04	// Amex ExpressPay 3.0
#define KERNEL_5							0x05	// JCB
#define KERNEL_6							0x06	// Discover D-PAS
#define KERNEL_7							0x07	// China UnionPay
#define KERNEL_EFTPOS						0xA0	// EFTPOS Contactless (not under EMVco kernels list)
#define KERNEL_PURE							0x0B	// Gemalto PURE contacless kernel
#define KERNEL_NA							0x00

// Outcomes
#define OUTCOME_APPROVED					0x01
#define OUTCOME_DECLINED					0x02
#define OUTCOME_ONLINE_REQUIRED				0x03
#define OUTCOME_ANOTHER_INTERFACE			0x04
#define OUTCOME_SELECT_NEXT					0x05
#define OUTCOME_TRY_AGAIN					0x06
#define OUTCOME_END_APPLICATION				0x07
#define OUTCOME_DONE						0xF0

// Starting Points
#define START_A								0x01
#define START_B								0x02
#define START_C								0x03
#define START_D								0x04
#define START_EXIT							0xFF
#define START_NA							0x00

// Messages Identifiers
#define MSG_APPROVED						0x03
#define MSG_DECLINED						0x07
#define MSG_ENTER_PIN						0x09
#define MSG_PROCESSING_ERROR				0x0F
#define MSG_REMOVE_CARD						0x10
#define MSG_WELCOME							0x14
#define MSG_PRESENT_CARD					0x15
#define MSG_PROCESSING_CARD					0x16
#define MSG_CARD_READ_REMOVE				0x17
#define MSG_ANOTHER_INTERFACE				0x18
#define MSG_PRESENT_ONLY_ONE_CARD			0x19
#define MSG_APPROVED_SIGN					0x1A
#define MSG_AUTHORIZING						0x1B
#define MSG_OTHER_CARD						0x1C
#define MSG_INSERT_CARD						0x1D
#define MSG_CLEAR_DISPLAY					0x1E
#define MSG_SEE_PHONE						0x20
#define MSG_PRESENT_CARD_AGAIN				0x21
#define MSG_USE_ANOTHER_VISA_CARD			0x22
#define MSG_REFER_TO_PAYMENT_DEVICE			0xFE	// Proprietary Message ID for Visa Kernel C3
#define MSG_NA								0xFF

// Transaction Status
#define STATUS_NOT_READY					0x00
#define STATUS_IDLE							0x01
#define STATUS_READY_TO_READ				0x02
#define STATUS_PROCESSING					0x03
#define STATUS_CARD_READ_SUCCESS			0x04
#define STATUS_PROCESSING_ERROR				0x05
#define STATUS_ONLINE_AUTHORIZING			0x06
#define STATUS_NONE							0xFF

// Value Qualifiers
#define	VALUE_NA							0x00
#define	VALUE_AMOUNT						0x01
#define VALUE_BALANCE						0x02

// CVM Processed / To Process
#define CVM_NO_CVM							0x00
#define CVM_SIGNATURE						0x01
#define CVM_ONLINE_PIN						0x02
#define CVM_CONFIRMATION_CODE				0x03
#define CVM_NA								0xFF

// Online Response Data Type
#define	ONLINE_RESP_NA						0xF0
#define	ONLINE_RESP_EMV_DATA				0x01
#define	ONLINE_RESP_ANY_DATA				0x02

// Alternate Interface
#define	ALT_INTERF_CONTACT_CHIP				0x00
#define	ALT_INTERF_MAGNETIC_STRIPE			0x01
#define	ALT_INTERF_NA						0xF0

// Field Off Request
#define FIELD_OFF_REQUEST_NA				0xFF

// Minimum length of AID
#define AID_MIN_SIZE 5

// Maximum length of AID buffers
#define AID_MAX_SIZE 16

// ********** CONTACTLESS **********
struct emv_ctls_prop_bytes_obj
{
	bool   			present;		/* Presence */
	unsigned long 	tag;			/* tag */
	unsigned int 	len;			/* number of octets */
	char 			*data;			/* octet string */

	char 			format;
	/* 'n': Numeric					*/
	/* 'c': Compressed Numeric		*/
	/* 'a' : Alphanumeric			*/
	/* 's': Alphanumeric Special	*/
	/* 'b': Binary					*/
	char 			category;
	/* Application : 'A'            */
	/* Terminal : 'T'               */
	/* Proprietary : 'P'            */
};

// ********** CONTACTLESS **********
struct emv_ctls_entrypoint_config
{
	struct emv_ctls_prop_bytes_obj kernel_id;				// Kernel ID (0x9F2A)
	struct emv_ctls_prop_bytes_obj appli_id;				// Application ID ("APP")
	struct emv_ctls_prop_bytes_obj trans_type;				// Transaction Type (0x9C)
	struct emv_ctls_prop_bytes_obj status_check_support;	// Status Check Support Flag (0xDF01)
	struct emv_ctls_prop_bytes_obj zero_amount_allowed;		// Zero Amount Allowed Flag	(0xDF02)
	struct emv_ctls_prop_bytes_obj reader_trans_limit;		// Reader Contactless Transaction Limit (0xDF03)
	struct emv_ctls_prop_bytes_obj reader_floor_limit;		// Reader Contactless Floor Limit (0xDF04)
	struct emv_ctls_prop_bytes_obj term_floor_limit;		// Terminal Floor Limit (0x9F1B)
	struct emv_ctls_prop_bytes_obj reader_cl_cvm_limit;		// Reader CVM Required Limit (0xDF05)
	struct emv_ctls_prop_bytes_obj term_trans_qualifiers;	// Terminal Transaction Qualifiers (0x9F66)
	struct emv_ctls_prop_bytes_obj ext_select_support;		// Extended Selection Support Flag (0x9F29)
	struct emv_ctls_prop_bytes_obj preproc_support;			// Pre Processing Support Flag according to Entry Points Specs (0xDF06)
	struct emv_ctls_prop_bytes_obj exact_matching;			// Exact Matching Flag (opposite of Application Selection Indicator) (0xDF07)
	struct emv_ctls_prop_bytes_obj amex_limits;				// Amex Rules For Limits Flag (0xDF08)
};

struct emv_ctls_property_config
{
	struct
	{
		int						count; 			/* Supported Applications Count */
		struct emv_ctls_ApplicationInfo
		{
			struct emv_ctls_prop_bytes_obj id_84;		/* DF Name ("APP")*/
			struct emv_ctls_prop_bytes_obj id_9C;		/* Transaction Type */
			struct emv_ctls_prop_bytes_obj id_9F01;		/* Acquirer Identifier */
			struct emv_ctls_prop_bytes_obj id_9F06;		/* AID */
			struct emv_ctls_prop_bytes_obj id_9F09;		/* Application Version Number */
			struct emv_ctls_prop_bytes_obj id_9F6D;		/* C2 MagStripe Application Version Number / C4 Reader Capabilities */
			struct emv_ctls_prop_bytes_obj id_9F15;		/* Merchant Category Code */
			struct emv_ctls_prop_bytes_obj id_9F35;		/* Terminal Type */
			struct emv_ctls_prop_bytes_obj id_9F40;		/* Additional Terminal Capabilities */
			struct emv_ctls_prop_bytes_obj id_9F6E;		/* C4 Transaction Capabilities */
			struct emv_ctls_prop_bytes_obj id_9F7E;		/* C2 Mobile Support Indicator */
			struct emv_ctls_prop_bytes_obj id_DF810C;	/* C2 Kernel ID */
			struct emv_ctls_prop_bytes_obj id_DF8117;	/* C2 Card Data Input Capability */
			struct emv_ctls_prop_bytes_obj id_DF8118;	/* C2 CVM Capability for CVM Required */
			struct emv_ctls_prop_bytes_obj id_DF8119;	/* C2 CVM Capability for CVM NOT Required */
			struct emv_ctls_prop_bytes_obj id_DF811A;	/* C2 Default UDOL */
			struct emv_ctls_prop_bytes_obj id_DF811B;	/* C2 Kernel Configuration */
			struct emv_ctls_prop_bytes_obj id_DF811E;	/* C2 MagStripe CVM Capability for CVM Required */
			struct emv_ctls_prop_bytes_obj id_DF811F;	/* C2 Security Capability */
			struct emv_ctls_prop_bytes_obj id_DF8120;	/* C2 Terminal Action Code - Default */
			struct emv_ctls_prop_bytes_obj id_DF8121;	/* C2 Terminal Action Code - Denial */
			struct emv_ctls_prop_bytes_obj id_DF8122;	/* C2 Terminal Action Code - Online */
			struct emv_ctls_prop_bytes_obj id_DF8123;	/* C2 Contactless Reader Floor Limit */
			struct emv_ctls_prop_bytes_obj id_DF8124;	/* C2 Contactless Transaction Limit for No On-device */
			struct emv_ctls_prop_bytes_obj id_DF8125;	/* C2 Contactless Transaction Limit for On-device */
			struct emv_ctls_prop_bytes_obj id_DF8126;	/* C2 Contactless Reader CVM Required Limit */
			struct emv_ctls_prop_bytes_obj id_DF812C;	/* C2 MagStripe CVM Capability for CVM NOT Required */
			struct emv_ctls_prop_bytes_obj id_DF812D;	/* C2 Message Hold Time */
			struct emv_ctls_prop_bytes_obj id_DF8130;	/* C2 Hold Time Value */
			struct emv_ctls_prop_bytes_obj id_DF8131;	/* C2 Phone Message Table */
			struct emv_ctls_prop_bytes_obj id_FF0D;		/* EFTPOS TAC-default (Terminal Action Codes) */
			struct emv_ctls_prop_bytes_obj id_FF0E;		/* EFTPOS TAC-Offline (Terminal Action Codes) */
			struct emv_ctls_prop_bytes_obj id_FF0F;		/* EFTPOS TAC-Online (Terminal Action Codes) */

			struct emv_ctls_prop_bytes_obj id_ExtraTags;	/* Extra Tags, using template 0x70 */
		} *appl;  								/* Pointer on an array of supported applications */
	} appliInfo;

	struct
	{
		int						count; 			/* Supported Dynamic Reader Limits Set Count */
		struct emv_ctls_DynReaderLimitsInfo
		{
			struct emv_ctls_prop_bytes_obj id_84;		/* DF Name ("DRL")*/
			struct emv_ctls_prop_bytes_obj id_9F5A;		/* Program ID */
			struct emv_ctls_prop_bytes_obj id_DF01;		/* Status Check Support Flag */
			struct emv_ctls_prop_bytes_obj id_DF02;		/* Zero Amount Allowed Flag */
			struct emv_ctls_prop_bytes_obj id_DF03;		/* Reader Contactless Transaction Limit */
			struct emv_ctls_prop_bytes_obj id_DF04;		/* Reader Contactless Floor Limit */
			struct emv_ctls_prop_bytes_obj id_DF05;		/* Reader Contactless CVM Required Limit */
		} *drl;  								/* Pointer on an array of supported dynamic reader limits set */
	} drlInfo;

	struct
	{
		struct emv_ctls_prop_bytes_obj	id_5F2A;	/* Transaction Currency Code */
		struct emv_ctls_prop_bytes_obj	id_5F57;	/* Account Type */
		struct emv_ctls_prop_bytes_obj	id_9C00;	/* Transaction Information Status sale, goods, services */
		struct emv_ctls_prop_bytes_obj	id_9C01;	/* Transaction Information Status cash */
		struct emv_ctls_prop_bytes_obj	id_9C09;	/* Transaction Information Status cashback */
		struct emv_ctls_prop_bytes_obj	id_9C20;	/* Transaction Information Status refund */
		struct emv_ctls_prop_bytes_obj	id_9F16;	/* Merchant Identifier */
		struct emv_ctls_prop_bytes_obj	id_9F1A;	/* Terminal Country Code */
		struct emv_ctls_prop_bytes_obj	id_9F1C;	/* Terminal ID */
		struct emv_ctls_prop_bytes_obj	id_9F1E;	/* Interface Device Serial Number */
		struct emv_ctls_prop_bytes_obj	id_9F25;	/* Terminal Entry Capability */
		struct emv_ctls_prop_bytes_obj	id_9F33;	/* Terminal Capabilities */
		struct emv_ctls_prop_bytes_obj	id_9F4E;	/* Merchant Name and Location */
		struct emv_ctls_prop_bytes_obj	id_FF0D;	/* TAC-default (Terminal Action Codes) */
		struct emv_ctls_prop_bytes_obj	id_FF0E;	/* TAC-Offline (Terminal Action Codes) */
		struct emv_ctls_prop_bytes_obj	id_FF0F;	/* TAC-Online (Terminal Action Codes) */
		struct emv_ctls_prop_bytes_obj	id_DF8104;	/* C2 Preset Balance Before Generate AC */
		struct emv_ctls_prop_bytes_obj	id_DF8105;	/* C2 Preset Balance After Generate AC */
		struct emv_ctls_prop_bytes_obj	id_DF811C;	/* C2 Maximum Lifetime for Torn Record */
		struct emv_ctls_prop_bytes_obj	id_DF811D;	/* C2 Maximum Number for Torn Record */
		struct emv_ctls_prop_bytes_obj	id_DFDF01;	/* Certificate Revocation List (proprietary) */
		struct emv_ctls_prop_bytes_obj	id_DFDF06;	/* Authorization Response (proprietary) */
		struct emv_ctls_prop_bytes_obj	id_DFDF13;	/* Debug card exchanges trace (proprietary for test only) */
		struct emv_ctls_prop_bytes_obj	id_DFDF14;	/* Direct AID to select (proprietary used if PPSE not supported; Amex only requirements) */
		struct emv_ctls_prop_bytes_obj	id_DFDF16;  /* Issuer Script max size */
		struct emv_ctls_prop_bytes_obj	id_DFDF20;  /* C3 Tracks Supported */
		struct emv_ctls_prop_bytes_obj  id_DFDF21;  /* C3 Cryptogram Supported */
		struct emv_ctls_prop_bytes_obj  id_DFDF23;	/* C4 Reader Features */
		struct emv_ctls_prop_bytes_obj  id_DFDF24;	/* C4 "Remove card" Message Hold Time */
		struct emv_ctls_prop_bytes_obj  id_DFDF25;	/* C4 "Present card again" Message Hold Time / RF Off Time */
		struct emv_ctls_prop_bytes_obj  id_DFDF26;	/* C4 "See phone" Message Hold Time / RF Off Time */
		struct emv_ctls_prop_bytes_obj	id_DFDF50;	/* EFTPOS Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF51;	/* C6 Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF52;	/* C2 EMV Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF53;	/* C2 MagStripe Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF54;	/* C3 EMV Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF55;	/* C3 MagStripe CVN17 Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF56;	/* C3 MagStripe Legacy Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF57;	/* C4 EMV Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF58;	/* C4 MagStripe Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF59;	/* C5 EMV Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF60;	/* C5 MagStripe Clearing Tags */
		struct emv_ctls_prop_bytes_obj	id_DFDF99;	/* Entry Point - Corresponding Kernel IDs by indexes */

		struct emv_ctls_prop_bytes_obj  id_ExtraTags;	/* Extra Tags using template 0x70 */
	} terminalInfo;
};

struct ctls_data_object {
	unsigned long	tag;		/* tag */
	unsigned int	len;		/* number of octets */
	byte			*data;		/* octet string */
	byte			req;		/* Requirement : */
								/* 'C' => Conditional */
								/* 'M' => Mandatory */
								/* 'R' => Required */
								/* 'O' => Optional */
	byte			format;		/* 'n': Numeric */
								/* 'c': Compressed Numeric */
								/* 'a': Alphanumeric */
								/* 's': Alphanumeric Special */
								/* 'b': Binary */
	byte			source;		/* Card: 'C' */
								/* Terminal: 'T' */
								/* Issuer: 'I' */
	byte			sfi;		/* SFI of the tag */
	unsigned int	maxlen;		/* maximum number of octets */
#ifdef CONFIG_EMV_CORE_DATA_ELEMENTS_HAVE_TRACE_TURN_OFF
	char * info;
#endif
};

typedef struct emv_ctls_entrypoint_config 		ENTRY_POINT_CONFIG;
typedef struct emv_ctls_property_config 		*EMV_CTLS_PROPERTY_HANDLE;

typedef struct
{
	EMV_CTLS_PROPERTY_HANDLE	ctls_property;	// Contactless Database
	EMV_CRYPTO_HANDLE			crypto;
	int							crypto_num_keys;
	int 						(*process_online_auth)(byte *onLineData, int datalen, byte *onLineResp, int *len); // online authorisation callback
	void 						(*process_online_reversal)(byte *onLineData, int datalen); // online reversal callback
	byte 						(*process_referral)(byte *referralData, int datalen, byte *referralResp, int *len); // voice referral callback
	void 						(*process_completion)(byte *completionData, int datalen); // completion callback (send ODC or store BDC)
	void 						(*process_store_proprietary_tlv)(TLV *t); // proprietary data element from card
	int 						(*get_pin)(byte *test_pin, unsigned int *length, unsigned int timeout);
	void 						(*set_status)(emv_set_status status); // indicate card status change
	void 						(*log_info)(emv_log_type log_type, byte *data, int value); // logging callback
} EMV_CTLS_PARAMS;

// Contactless Candidate List
typedef struct
{
	struct list_elem 	elem;
	byte 				aid[AID_MAX_SIZE];
	int					aid_len;
	byte				priority;
	byte				kernelid;
	int					extselect_support;
	byte				extselect[8];
	int					extselect_len;
	byte				read_comb_index;
	TLV					tlv;
} CANDIDATE_CTLS_INFO;


// Entry Point

// Configurable rules.
#define MAX_RIDS_PER_RULE	10
typedef struct {
	uint8_t RIDCount;
	uint8_t RID[5][MAX_RIDS_PER_RULE];
} entrypoint_rule_t;


// User Interface Request Data Structure
typedef struct
{
	unsigned char message_id;					// Message Identifier
	unsigned char status;						// Transaction Status
	unsigned char hold_time[3];					// Holding Time
	unsigned char language_pref[8];				// Language Preference
	unsigned char value_qualifier;				// Value Qualifier
	unsigned char value[6];						// Value
	unsigned char currency_code[2];				// Currency Code

} USER_INTERFACE_REQUEST;


// Outcome Parameter Set Data Structure
typedef struct
{
	unsigned char start;						// Restarting Point
	unsigned char online_response;				// Online Response Data present
	unsigned char cvm;							// CVM
	unsigned char ui_req_outcome;				// User Interface Request present on Outcome
	unsigned char ui_req_restart;				// User Interface Request present on Restart
	unsigned char data_record;					// Data Record present
	unsigned char discretionary_data;			// Discretionary Data present
	unsigned char alt_interface_pref;			// Alternate Interface Preference
	unsigned char receipt;						// Receipt to Print
	unsigned char field_off_req;				// Field Off Request
	unsigned char removal_timeout;				// Removal Timeout
	USER_INTERFACE_REQUEST *ui_req_out;			// User Interface Request if present on Outcome
	USER_INTERFACE_REQUEST *ui_req_rest;		// User Interface Request if present on Restart

} OUTCOME_PARAMETER;

// Kernel Activation Register
typedef struct
{
	unsigned char kernel_id;
	int (*kernel_activation)(EMV_HANDLE hEMV);
} KERNEL_REGISTER;

typedef struct
{
	uint8_t mode;
	uint16_t timeout;
	uint8_t amp_diff;
	uint8_t amp_weighting;
	uint8_t phase_diff;
	uint8_t phase_weighting;
} hw_wake_up_t;

int ctls_l1_config_wake_up(hw_wake_up_t hw_wake_up);

// Transaction Data Structure
typedef struct
{
	unsigned char trans_type;					// Transaction Type
	unsigned char amount_authorized[6];			// Amount, Authorized
	unsigned char amount_other[6];				// Amount, Other
	unsigned char unpred_number[4];				// Unpredictable Number
	unsigned char trans_currency_code[2];		// Transaction Currency Code
	unsigned char balance_before[6];			// Balance Before Generate AC (Mastercard)
	unsigned char balance_after[6];				// Balance After Generate AC (Mastercard)
	unsigned char trans_category_code;			// Transaction Category Code (Mastercard)
	unsigned char kernel_id;					// Kernel Identifier to be used: determined in Combination Selection
	unsigned long timeout;						// Maximum Polling Timeout to detect a card
	unsigned char date[3];						// Transaction Date
	unsigned char time[3];						// Transaction Time
	unsigned char outcome;						// Transaction Outcome
	unsigned char mode;							// Hardware Wakeup mode
	KERNEL_REGISTER kernels[NB_KERNELS];		// List of Kernels supported (ID + pointer to the activation function)
	EMV_CTLS_PARAMS params;						// Data Structure for EMV Parameters
	EMV_HANDLE hEMV;							// Handle on EMV Instance

	// Callback to Send Raw Tag Data to Terminal
	int (*process_events)(bool trans_in_progress);
	int (*process_signals)(void);
	int (*send_raw_data)(unsigned char *data, int data_len);
	// Callback to Send an User Interface Request to Terminal
	int (*send_user_interface)(USER_INTERFACE_REQUEST *user_req);
	// Callback to Send an Outcome Parameter Set to Terminal
	int (*send_outcome_param)(OUTCOME_PARAMETER *outcome_param, unsigned char *data_record, int data_record_len,
									unsigned char *discr_data, int discr_data_len,
									unsigned char *online_resp, int online_resp_len);
	// Callback to Send an Online Authorization
	int (*online_auth_request)(unsigned char *req, int req_len, unsigned char *resp, int *resp_len);
	int	(*check_exception_file)(byte *PAN, int PANlen);
	void (*process_candidate_list)(LIST *candidate_list);
} ENTRY_POINT_TRANS;

//

// To deal with long tag / long length tag
typedef struct {
	/* internal state */
	unsigned char _objptr[1280];
	unsigned char *_tag_ptr;
	unsigned char *_lenptr;			/* pointer to 'len' field */
	unsigned int _len;				/* 'outer' length, specified by user */
	unsigned int _offset;
	/* parsed information */
	unsigned long tag;			/* Tag tag */
	unsigned int len;			/* number of bytes */
	unsigned char *val;			/* byte string */
} TLV_long;
//


#ifdef __cplusplus
extern "C" {
#endif

// ********** CONTACTLESS **********
int EMV_CTLS_Init(EMV_CTLS_PARAMS *params, EMV_HANDLE *hEMV);
int EMV_CTLS_Terminate(EMV_HANDLE hEMV);
int CTLS_check(void);

int EMV_CTLS_ContextInit(EMV_HANDLE hEMV);
int EMV_CTLS_GetICSHash(EMV_HANDLE *hEMV, byte *hash, int *hashlen);
int EMV_CTLS_ContextReset(EMV_HANDLE hEMV);
int EMV_CTLS_ContextSetAmount(EMV_HANDLE hEMV,  byte *Amount, byte *CurrencyCode);
int EMV_CTLS_ContextSetAmountOther(EMV_HANDLE hEMV,  byte *Amount);
int EMV_CTLS_ContextSetTransactionType(EMV_HANDLE hEMV, byte Transaction);
int EMV_CTLS_ContextAddCurTime(EMV_HANDLE hEMV, byte curDate[6]);
bool EMV_CTLS_ContextIsTagExist(EMV_HANDLE hEMV, int tag);
int EMV_CTLS_ContextGetDataObject(EMV_HANDLE hEMV, int tag, struct ctls_data_object *pDataObject);
int EMV_CTLS_ContextUpdateDataObject(EMV_HANDLE hEMV, struct ctls_data_object *dob, byte updateByte, byte bit_mask);
int EMV_CTLS_ContextResetMainCardData(EMV_HANDLE hEMV);
// Return Transaction Mode
int EMV_CTLS_GetTransactionMode(EMV_HANDLE hEMV, byte *mode);

int EMV_CTLS_getDataTags(EMV_HANDLE hEMV, unsigned long tagName, byte *data, int *length);

// To deal with long tag / long length tag
int TLV_long_create(unsigned char *data, int len, TLV_long *t);
int TLV_long_find(TLV_long *parent, unsigned long tag, TLV_long *t);
int TLV_create_array(int tag, unsigned char *data, unsigned int data_len, unsigned char *tlv_buff);
//

//
int kernel2_initialize_signals_data(EMV_HANDLE hEMV);	// Special Functionality for Mastercard
int kernel2_clean_expired_torn(EMV_HANDLE hEMV);		// Special Functionality for Mastercard
// **********************************


/**
	Process a Transaction through Entry Point
 */
int entrypoint_transaction(ENTRY_POINT_TRANS *transact, ENTRY_POINT_CONFIG trans_config[NB_MAX_READER_COMBINATIONS]);

/**
	Configure entrypoint rules
 */
void entrypoint_configure_rules(const entrypoint_rule_t *_pRules, uint32_t _count);

/**
	Initialize Callbacks
 */
void entrypoint_init_callbacks(ENTRY_POINT_TRANS *transact);

// Kernels Activation functions to be registered in the terminal application

/**
	Kernel1 Activation
 */
int kernel1_activation(EMV_HANDLE hEMV);

/**
	Kernel2 Activation
 */
int kernel2_activation(EMV_HANDLE hEMV);

/**
	Kernel3 Activation
 */
int kernel3_activation(EMV_HANDLE hEMV);

/**
	Kernel4 Activation
 */
int kernel4_activation(EMV_HANDLE hEMV);

/**
	Kernel6 Activation
 */
int kernel6_activation(EMV_HANDLE hEMV);

/**
	EFTPOS Activation
 */
int kernelA_activation(EMV_HANDLE hEMV);

/**
	GEMALTO Activation
 */
int kernelB_activation(EMV_HANDLE hEMV);



#ifdef __cplusplus
}
#endif

#endif /* __EMV_CTLS_KERNEL_H__ */
