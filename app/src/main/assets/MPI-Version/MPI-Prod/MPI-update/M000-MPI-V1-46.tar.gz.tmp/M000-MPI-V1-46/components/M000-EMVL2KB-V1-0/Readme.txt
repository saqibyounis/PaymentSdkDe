Part No:		M000-EMVL2KB-V1-0
Description:	Miura Gemalto Pure Contactless Level 2 kernel
Date:			2017-01-27

For more information please see release note: M000-EMVL2KB-V1-0-RN.pdf
