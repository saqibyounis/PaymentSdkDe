#ifndef __EMV_KERNEL_H__
#define __EMV_KERNEL_H__

#ifndef bool
#define bool	int
#endif

#ifndef false
#define false	0
#endif

#ifndef true
#define true	1
#endif

#define CONFIG_EMV_CORE_ODA_LIST_MAX_SIZE			1250

#define EMV_SUCCESS                               	0
#define EMV_DATA_NOT_INITIALIZED					1
#define EMV_APPL_INIT_CONDITIONS_NOT_SATISFIED     	2
#define EMV_ABORTED                               	3
#define EMV_SCR_POWER_UP_FAILED						4
#define	EMV_CRYPTO_ERROR							5
#define EMV_ADDTAG									7
// these two are replaced by ONLINE_AUTH_* remove them (after updating test tool)
#define EMV_ONLINE_AUTH_UNABLETOGOONLINE			8
#define EMV_ONLINE_AUTH_RESPONSE_TIMEOUT			9

#define EMV_NO_ICC_RESPONSE							10
#define EMV_E_NOT_ACCEPTED						  	11
#define EMV_CANCELLED								12
#define EMV_CONDITIONS_NOT_SATISFIED				24

#define EMV_CHV_E_SUCCESS	0
#define EMV_CHV_E_ERROR		1	/* Generic error */
#define EMV_CHV_E_TIMEOUT	2 	/* PIN entry timeout*/
#define EMV_CHV_E_OVERFLOW	3	/* Buffer overflow */
#define EMV_CHV_E_BYPASS	4 	/* merchant selected pin bypass */

#define EMV_SCR_STATUS_CARD_PRESENT		0
#define EMV_SCR_STATUS_CARD_REMOVED		1

#define EMV_CRYPTO_MODULUS_SIZE_MAX		(2048/8)
#define EMV_CRYPTO_EXPONENT_SIZE_MAX	3

#define EMV_CVM_REQUIRES_SIGNATURE		0xA107
#define EMV_CVM_REQUIRES_ONLINEPIN		0xA108

#define MAX_PIN_LENGTH 12
#define MIN_PIN_LENGTH 4

#define TERMINAL_RESPONSE_DECLINE       0
#define TERMINAL_RESPONSE_APPROVE       1
#define TERMINAL_RESPONSE_TERMINATE     2
#define TERMINAL_RESPONSE_NOT_ACCEPTED  3

#define ONLINE_AUTH_SUCCESS				0x00
#define ONLINE_AUTH_ERROR				0x01
#define ONLINE_AUTH_TIMEOUT				0x02

#define REFERRAL_APPROVED				1
#define REFERRAL_DECLINED				0

#define TAG_AID 						0x4F
#define TAG_APPLICATION_LABEL			0x50
#define TAG_APPLICATION_TEMPLATE 		0x61
#define TAG_FCI_TEMPLATE 				0x6F
#define TAG_DF_NAME 					0x84
#define TAG_APPLICATION_PREFERRED_NAME 	0x9F12
#define TAG_ISSUER_CODE_TABLE_INDEX 	0x9F11

#define TAG_ISSUER_SCRIPT_RESULTS 		0x9F5B

#define CODE_TABLE_1					0x01

typedef unsigned char byte;

typedef enum {
	MSG_LAST_PIN_TRY,
	MSG_PIN_OK,
	MSG_INCORRECT_PIN,
	MSG_INVALID_PIN_LENGTH,
	MSG_PROCESSING
} emv_set_status;

typedef enum {
	EMV_LOG_FUNC_CALL,
	EMV_LOG_FUNC_RET,
	EMV_LOG_TLV,
	EMV_LOG_CMD_APDU,
	EMV_LOG_RESP_APDU,
	EMV_LOG_BUFFER
} emv_log_type;

struct emv_prop_bytes_obj {
	unsigned long tag;			/* tag */
	unsigned int len;			/* number of octets */
	char *data;					/* octet string */

	char format;
	/* 'n': Numeric					*/
	/* 'c': Compressed Numeric		*/
	/* 'a' : Alphanumeric			*/
	/* 's': Alphanumeric Special	*/
	/* 'b': Binary					*/
	char category;
	/* Application : 'A'            */
	/* Terminal : 'T'               */
	/* Proprietary : 'P'            */
};

struct emv_prop_int_obj {
	unsigned long  tag;			/* tag */
	unsigned int   len;			/* number of octets */
	unsigned int   value;		/* integer value */

	unsigned char  format;
	/* 'n': Numeric					*/
	/* 'c': Compressed Numeric		*/
	/* 'a' : Alphanumeric			*/
	/* 's': Alphanumeric Special	*/
	/* 'b': Binary					*/
	unsigned char  category;
	/* Application : 'A'            */
	/* Terminal : 'T'               */
	/* Proprietary : 'P'            */
	/* Kernel : 'K'            		*/
};

struct emv_property_config {
	struct  {
		int						count; /* Supported Applications Count */
		struct emv_ApplicationInfo{
			struct emv_prop_bytes_obj id_84;	/* DF Name */
			struct emv_prop_bytes_obj id_97;	/* Default TDOL */
			struct emv_prop_bytes_obj id_9F01;	/* Acquirer Identifier */
			struct emv_prop_bytes_obj id_9F06;	/* AID */
			struct emv_prop_bytes_obj id_9F09;	/* Application Version Number */
			struct emv_prop_bytes_obj id_9F1B;	/* Terminal Floor Limit */
			struct emv_prop_bytes_obj id_9F49;	/* Dynamic Authentication Data Object List (DDOL)*/
			/* Proprietary tags */
			struct emv_prop_int_obj id_e001;	/* ASI - Application Selection Indicator */
		} *appl;  /* Pointer on an array of supported applications */
	} appliInfo;

	struct  {
		struct emv_prop_bytes_obj	pse;		/* PSE name */
		struct emv_prop_bytes_obj	id_5F2A;	/* Currency Transaction Code */
		struct emv_prop_bytes_obj	id_9C00;	/* Transaction Information Status sale, goods, services*/
		struct emv_prop_bytes_obj	id_9C01;	/* Transaction Information Status cash*/
		struct emv_prop_bytes_obj	id_9C09;	/* Transaction Information Status cashback*/
		struct emv_prop_bytes_obj	id_9F0D;	/* IAC-Default (Issuer Action Codes) */
		struct emv_prop_bytes_obj	id_9F0E;	/* IAC-Offline (Issuer Action Codes) */
		struct emv_prop_bytes_obj	id_9F0F;	/* IAC-Online (Issuer Action Codes) */
		struct emv_prop_bytes_obj	id_9F1A;	/* Terminal Country Code */
		struct emv_prop_bytes_obj	id_9F1C;	/* Terminal ID */
		struct emv_prop_bytes_obj	id_DFDF00;	/* Transaction Info Status bits (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF01;	/* Revoked certificates list (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF02;	/* (ARQC) Data Objects Tags List required in online message (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF03;	/* Referral data list required by the referral process (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF04;	/* (ARPC) Data Objects Tags List required in online response message (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF05;	/* Reversal Data Objects Tags List required in a reversal (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF06;	/* Authorization Response (proprietary) */
		struct emv_prop_bytes_obj	id_FF0D;	/* TAC-default (Terminal Action Codes) */
		struct emv_prop_bytes_obj	id_FF0E;	/* TAC-Offline (Terminal Action Codes) */
		struct emv_prop_bytes_obj	id_FF0F;	/* TAC-Online (Terminal Action Codes) */
		struct emv_prop_bytes_obj	id_DFDF10;	/* Threshold Value for Biased Random Selection */
		struct emv_prop_bytes_obj	id_DFDF11;	/* Target Percentage for Random Selection (0 - 99 dec, or 0 -63 hex) */
		struct emv_prop_bytes_obj	id_DFDF12;	/* Maximum Target Percentage for Biased Random Selection (0 - 99 decimal, or 0 - 63 hex) */
		struct emv_prop_bytes_obj	id_DFDF13;	/* Default CVM (proprietary) */
		struct emv_prop_bytes_obj	id_DFDF16;  /* Issuer Script max size */
		struct emv_prop_bytes_obj   id_DFDF17;  /* Log data Objects required for the log file (proprietary) */
	} terminalInfo;

	const struct emv_KernelInfo {
		struct emv_prop_bytes_obj	id_9F33;	/* Terminal Capabilities */
		struct emv_prop_bytes_obj	id_9F35;	/* Terminal Type */
		struct emv_prop_bytes_obj	id_9F40;	/* Additional Terminal Capabilities */
	} *kernelInfo;
};

typedef struct AFL_ELEMENT {
	byte sfi;
	byte first_byte;
	byte last_byte;
	byte oda_counter;
} Afl_Element;

typedef struct ODA_LIST_ELEMENT {
	byte sfi;
	byte *oda_record;
} ODA_ELEMENT;

typedef struct {
	/* internal state */
	unsigned char _objptr[256];
	unsigned char *_tag_ptr;
	unsigned char *_lenptr;			/* pointer to 'len' field */
	unsigned int _len;				/* 'outer' length, specified by user */
	unsigned short _offset;
	/* parsed information */
	unsigned long tag;			/* Tag tag */
	unsigned short len;			/* number of bytes */
	unsigned char *val;			/* byte string */
} TLV;

struct data_object {
	unsigned long   tag;	    /* tag */
	unsigned int    len;	    /* number of octets */
	byte 			*data;		/* octet string */
	byte  			req;		/* Requirement : */
								/* 'C' => Conditional */
								/* 'M' => Mandatory */
								/* 'R' => Required */
								/* 'O' => Optional */
	byte			format;		/* 'n': Numeric				*/
								/* 'c': Compressed Numeric		*/
								/* 'a': Alphanumeric			*/
								/* 's': Alphanumeric Special	*/
								/* 'b': Binary					*/
	byte			source;	    /* Card: 'C'		*/
								/* Terminal: 'T'	*/
								/* Issuer: 'I'		*/
	byte			sfi;	   	/* SFI of the tag */
};

struct emv_crypto_pubkey {
	int       	mod_len;						   /* length of modulus n in octets */
	byte        mod[EMV_CRYPTO_MODULUS_SIZE_MAX];  /* modulus: p * q */
	byte        exp[EMV_CRYPTO_EXPONENT_SIZE_MAX]; /* exponent: relatively prime to (p-1) * (q-1) */
	int			exp_len;
	byte      	algo_id;
	byte       	hash_id;
};

struct CAKey {
	char *rid; /* RID */
	int index; /* Certificate Authority Index */
	short size; /* Size (bits) */
	char *exp; /* Certificate Authority Public Key Exponent */
	char *checksum; /* Certification Authority Public Key Checksum */
	char *pubkey; /* Certificate Authority Public Key */
};

typedef void *EMV_HANDLE;
typedef const struct emv_property_config *EMV_PROPERTY_HANDLE;
typedef struct CAKey *EMV_CRYPTO_HANDLE;

typedef struct {
	EMV_PROPERTY_HANDLE     property;
	EMV_CRYPTO_HANDLE		crypto;
	int						crypto_num_keys;
	int 					(*process_online_auth)(byte *onLineData, int datalen, byte *onLineResp, int *len); // online authorisation callback
	void 					(*process_online_reversal)(byte *onLineData, int datalen); // online reversal callback
	byte 					(*process_referral)(byte *referralData, int datalen, byte *referralResp, int *len); // voice referral callback
	void 					(*process_completion)(byte *completionData, int datalen); // completion callback (send ODC or store BDC)
	void 					(*process_store_proprietary_tlv)(TLV *t); // proprietary data element from card
	int 					(*get_pin)(byte *test_pin, unsigned int *length, unsigned int timeout);
	void 					(*set_status)(emv_set_status status); // indicate card status change
	void 					(*log_info)(emv_log_type log_type, byte *data, int value); // logging callback
} EMV_PARAMS;

struct list_elem {
	struct list_elem *prev;     /* Previous list element. */
	struct list_elem *next;     /* Next list element. */
};

typedef struct LIST {
	struct list_elem head;      /* List head. */
	struct list_elem tail;      /* List tail. */
} LIST;

typedef struct {
	struct list_elem 	elem;
	TLV					tlv;
	byte				priority;
} CANDIDATE_INFO;

#ifdef __cplusplus
extern "C" {
#endif

int EMV_Init(EMV_PARAMS *params, EMV_HANDLE *hEMV, char *emvL1device);
int EMV_Terminate(EMV_HANDLE hEMV);

#define MODE_SET	1
#define MODE_RESET	2
int EMV_ContextInitFix(char mode);
int EMV_ContextInit(EMV_HANDLE hEMV);
// GetICSHash should only be called after EMV_ContextInit
int EMV_GetICSHash(EMV_HANDLE *hEMV, byte *hash, int *hashlen); // Kernel 2.1 returns 0 + 4 byte hash

int EMV_ContextReset(EMV_HANDLE hEMV);
int EMV_ContextSetAmount(EMV_HANDLE hEMV,  byte *Amount, byte *CurrencyCode);
int EMV_ContextSetAmountOther(EMV_HANDLE hEMV,  byte *Amount);
int EMV_ContextSetTransactionType(EMV_HANDLE hEMV, byte Transaction);
int EMV_ContextAddCurTime(EMV_HANDLE hEMV, byte curDate[6]);
bool EMV_ContextIsTagExist(EMV_HANDLE hEMV, int tag);
int EMV_ContextGetDataObject(EMV_HANDLE hEMV, int tag, struct data_object *pDataObject);
int EMV_ContextUpdateDataObject(EMV_HANDLE hEMV, struct data_object *dob, byte updateByte, byte bit_mask);

int EMV_get_scr_status(EMV_HANDLE *hEMV, int *SCRStatus);
int EMV_power_up_scr(EMV_HANDLE *hEMV);
int EMV_power_down_scr(EMV_HANDLE *hEMV);

int EMV_InitiateApplicationProcessing(EMV_HANDLE hEMV, TLV *tlv_Appl, TLV *tlv_AIP);
int EMV_ApplSelectionInit(EMV_HANDLE hEMV);
int EMV_ApplSelectionReset(EMV_HANDLE hEMV);
int EMV_ApplSelectionBuildTerminalList(EMV_HANDLE hEMV);
int EMV_ApplSelectionBuildCandidateList(EMV_HANDLE hEMV, LIST **candidate_list);
int EMV_SelectApplication(EMV_HANDLE hEMV, TLV *fci, TLV *tlv_Appl);
int EMV_CardActionAnalysis(EMV_HANDLE hEMV, byte *pGenACData, int data_len, byte *odaList, int oda_len);
int EMV_CardHolderVerification(EMV_HANDLE hEMV, const byte *odaList, int oda_len);
int EMV_RequestApplCryptogram(EMV_HANDLE hEMV, byte issuance, byte crypto_type, byte *pGenACData, int *data_len);
int EMV_ProcessScript(EMV_HANDLE hEMV, byte scriptType);
int EMV_OfflineDataAuth(EMV_HANDLE hEMV, byte *odaList, int oda_len);
int EMV_OnlineProcessing(EMV_HANDLE hEMV);
int EMV_ProcessRestrictions(EMV_HANDLE hEMV);
int EMV_ReadApplData(EMV_HANDLE hEMV, TLV *tlv_AIP, byte *pOdaList, int *oda_len);
int EMV_TerminalActionAnalysis(EMV_HANDLE hEMV, byte *crypto_type);
int EMV_TerminalRiskMng(EMV_HANDLE hEMV);
int EMV_forceOnline(EMV_HANDLE hEMV);
int EMV_Completion(EMV_HANDLE hEMV, byte *term_resp, byte *odaList, int oda_len);

int Add2numAmounts (unsigned char *Amount1, const unsigned char *Amount2);
bool binaryAmount2Numeric(unsigned long Amount, unsigned char *numAmount, int size);
const char *hexdump(const void *data, unsigned int len);
int TLV_create(unsigned char *data, int len, TLV *t);
int TLV_find(TLV *parent, int tag, TLV *t);
unsigned short TLV_raw_tag(TLV *t);
int TLV_decode_tlv(const byte *header, const byte *endbuf, unsigned long *tag, unsigned short *len, byte **val);
int TLV_is_privateclass(unsigned long tag);
int TLV_is_constructed(unsigned long tag);
int EMV_getDataTags(EMV_HANDLE hEMV, unsigned long tagName, byte *data, int *length);

int list_size (LIST *);
struct list_elem *list_begin(LIST *l);
struct list_elem *list_next(struct list_elem *);
struct list_elem *list_end(LIST *);
struct list_elem *list_pop_front (LIST *);
int list_empty (LIST *);
struct list_elem * list_remove (struct list_elem *elem);

#ifdef __cplusplus
}
#endif

#endif /* __EMV_KERNEL_H__ */
