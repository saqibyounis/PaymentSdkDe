Part No:		M000-EMVL2EP-V1-11
Description:	Miura Contactless Entry Point library
Date:			2017-01-26

For more information please see release note: M000-EMVL2EP-V1-11-RN.pdf

