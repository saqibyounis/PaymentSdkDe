Part No:		M000-EMVL2CL-V1-12
Description:	Miura Contactless support library
Date:			2016-01-26

For more information please see release note: M000-EMVL2CL-V1-12-RN.pdf

