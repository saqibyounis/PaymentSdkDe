Part No: 	M000-EMVL2KA-V1-1
Title:		Miura EFTPOS Contactless Level 2 Kernel
Release Date:	2015-10-15


See Release note M000-EMVL2KA-V1-1-RN.pdf for more details.