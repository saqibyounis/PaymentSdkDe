Part No:		M000-EMVL2L-V3-6
Description:	Miura EMV Level 2 support library
Date:			2017-01-26

For more information please see release note: M000-EMVL2L-V3-6-RN.pdf
