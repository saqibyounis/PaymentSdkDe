Part No:		M000-EMVL2K4-V1-6
Description:	Miura Contactless AmEx ExpressPay library
Date:			2018-06-11

For more information please see release note: M000-EMVL2K4-V1-6-RN.pdf

