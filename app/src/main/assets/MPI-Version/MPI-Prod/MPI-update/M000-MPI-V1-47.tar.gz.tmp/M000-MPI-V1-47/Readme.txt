Part No:     M000-MPI-V1-47
Description: Miura Payments Interface (MPI), version 1-47
Date:        2018-07-27

For more information please see release note: M000-MPI-V1-47-RN.pdf
