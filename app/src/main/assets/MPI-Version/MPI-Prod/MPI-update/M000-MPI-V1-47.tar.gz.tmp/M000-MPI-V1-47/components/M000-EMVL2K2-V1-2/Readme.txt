Part No:		M000-EMVL2K2-V1-2
Description:	Miura Contactless PayPass library
Date:			2018-04-23

For more information please see release note: M000-EMVL2K2-V1-2-RN.pdf

