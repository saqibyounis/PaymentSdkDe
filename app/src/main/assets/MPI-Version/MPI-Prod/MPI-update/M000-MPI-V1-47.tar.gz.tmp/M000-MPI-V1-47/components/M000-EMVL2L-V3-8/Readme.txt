Part No:		M000-EMVL2L-V3-8
Description:	Miura EMV Level 2 support library
Date:			2017-12-01

For more information please see release note: M000-EMVL2L-V3-8-RN.pdf
