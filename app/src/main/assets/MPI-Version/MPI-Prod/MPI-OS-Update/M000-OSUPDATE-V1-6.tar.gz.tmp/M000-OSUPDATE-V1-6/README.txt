Part No:         M000-*OSUPDATE-V1-6
Title:           Miura OS Upgrade Script
Release Date:    2016-09-21

Description:
This is an upgrade package which will upgrade a Miura Operating System.

Installation:
This package has been tested on and signed to run on Miura Operating Systems V5-10 and above:
Part No:    M000-*OS-V5-10

MSD
Copy this archive to the PED along with the M000-*OS-Vx-x.tar.gz you wish to upgrade to.
Eject the MSD
Unplug the MSD

Via MPI Protocol.
Copy this archive to the PED along with the M000-*OS-Vx-x.tar.gz you wish to upgrade to.
Call Reset Device, P1==1.


