Part No:     M000-MPI-V1-46
Description: Miura Payments Interface (MPI), version 1-46
Date:        2017-09-29

For more information please see release note: M000-MPI-V1-46-RN.pdf
