Part No:		M000-EMVL2KB-V1-1
Description:	Miura Gemalto Pure Contactless Level 2 kernel
Date:			2017-09-21

For more information please see release note: M000-EMVL2KB-V1-1-RN.pdf
