Part No:		M000-EMVL2CL-V1-15
Description:	Miura Contactless support library
Date:			2018-06-20

For more information please see release note: M000-EMVL2CL-V1-15-RN.pdf

