Part No:		M000-EMVL2EP-V1-13
Description:	Miura Contactless Entry Point library
Date:			2018-06-20

For more information please see release note: M000-EMVL2EP-V1-13-RN.pdf

