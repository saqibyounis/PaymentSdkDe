Part No:         M100-OSUPDATE-V1-0
Title:           Miura (M100) OS Upgrade Script
Release Date:    2015-12-03

Description:
This is an upgrade package which will upgrade a Miura M100-OS on ITP (M101) or POSZLE (M104).

Installation:
This package has been tested on and signed to run on Miura O/S M100-OS-V1-0 and above:
Part No:    M100-OS-V1-0

USB Stick:
Copy this archive to a USB stick along with the M100-OS-Vx-x.tar.gz you wish to upgrade to.
Get the ITP/POSZLE into the appropriate state, either:
	* Ready To Install (factory use only).
	* Revive-9 mode (see M100 O/S user guide).
	* M100-RPI running (idle/disconnected).
Insert USB stick into ITP or POSZLE device.
Wait for device to reboot and start up again.
Remove the USB stick.

Via M100-RPI Protocol:
Copy this archive to the ITP or POSZLE along with the M100-OS-Vx-x.tar.gz you wish to upgrade to.
Call RESET DEVICE with P1=1.

