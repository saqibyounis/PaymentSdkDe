Part No:     M100-RPI-V1-6
Description: Retail POS Interface (Application For ITP and POSzle)
Date:        2017-05-03

For more information please see release note: M100-RPI-V1-6-RN.pdf
